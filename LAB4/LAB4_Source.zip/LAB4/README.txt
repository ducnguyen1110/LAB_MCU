LAB 4 - COOPERATIVE SCHEDULER

Firmware/ contains the complete STM32CubeIDE project and HAL/CMSIS sources.
Import it as an existing project. The main application is in Core/Src/main.c.
The scheduler implementation and interface are in Core/Src/scheduler.c and
Core/Inc/scheduler.h.

Proteus/lab4.pdsprj is the simulation project. After extracting the archive,
open the schematic and select Firmware/Debug/LAB4.hex in the STM32 Program
File field if Proteus still points to a path on another computer. The Virtual
Terminal uses 115200 baud, 8N1.

tests/ contains the optional host test suite. With Python and native GCC on
PATH, run 'python tests/run_tests.py' from the extracted LAB4 directory.
